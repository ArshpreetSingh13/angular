export interface Spinner {
    
}
